import os
import math
import matplotlib.pyplot as plt

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

# =====================================================================
# 1. DATASET
#    range_m     : typical OUTDOOR / open-area range (see 'range_basis').
#                  Indoor range is much lower for Bluetooth and Wi-Fi.
#    rate_mbps   : peak (PHY-layer) data rate, NOT sustained user throughput.
#    tx_dbm      : typical transmit power of the user DEVICE (client / mobile station).
#    sources     : numbers refer to the source list at the bottom of this file.
# =====================================================================
DATA = [
    {
        "name": "Bluetooth 5 (BLE)", "category": "WPAN",
        "range_m": 50, "rate_mbps": 2.0, "tx_dbm": 0, "band": "2.4 GHz",
        "range_basis": "Bluetooth 5 nominal range 30-50 m (BLE 4: 10-30 m)",
        "rate_basis": "2 Mbps PHY (about 1.4 Mbps application throughput)",
        "power_basis": "0 dBm (1 mW) basic level; 4/10/20 dBm optional",
        "sources": [1, 2, 13],
    },
    {
        "name": "Wi-Fi 5 (802.11ac)", "category": "WLAN",
        "range_m": 305, "rate_mbps": 867, "tx_dbm": 18, "band": "5 GHz",
        "range_basis": "about 1,000 ft outdoors (typical, line of sight); about 90 ft indoors",
        "rate_basis": "867 Mbps (2x2 MIMO, 80 MHz channel)",
        "power_basis": "about 18 dBm typical client; adapters limited to 23 dBm EIRP at 5 GHz (EU)",
        "sources": [3, 4, 5, 6, 10],
    },
    {
        "name": "Wi-Fi 6 (802.11ax)", "category": "WLAN",
        "range_m": 274, "rate_mbps": 2400, "tx_dbm": 18, "band": "2.4 / 5 / 6 GHz",
        "range_basis": "about 900 ft outdoors at 5 GHz (typical, line of sight); about 50 ft indoors",
        "rate_basis": "2.4 Gbps (2x2 MIMO, 160 MHz channel)",
        "power_basis": "about 18 dBm typical client; adapters limited to 23 dBm EIRP at 5 GHz (EU)",
        "sources": [3, 4, 5, 10, 12],
    },
    {
        "name": "WiMAX 802.16e", "category": "WMAN",
        "range_m": 5000, "rate_mbps": 63, "tx_dbm": 23, "band": "2-6 GHz",
        "range_basis": "typical cell radius 2-5 km (1 km dense urban, up to 5 km rural)",
        "rate_basis": "63 Mbps downlink / 28 Mbps uplink per sector, 10 MHz channel",
        "power_basis": "mobile station +23 dBm (200 mW); base station about +43 dBm (20 W)",
        "sources": [7, 8, 9],
    },
    {
        "name": "WiMAX 802.16m", "category": "WMAN",
        "range_m": 10000, "rate_mbps": 100, "tx_dbm": 23, "band": "2-6 GHz",
        "range_basis": "up to about 10 km (secondary source, lower confidence)",
        "rate_basis": "100 Mbps mobile (1 Gbps stationary) peak (secondary source)",
        "power_basis": "ASSUMED same class as 802.16e: mobile station +23 dBm",
        "sources": [11],
    },
]

# =====================================================================
# 2. DERIVED FIGURES OF MERIT
# =====================================================================
for t in DATA:
    t["tx_mw"] = 10 ** (t["tx_dbm"] / 10)                        # dBm -> mW
    t["mbps_per_m"] = t["rate_mbps"] / t["range_m"]               # throughput per metre of range
    t["mbps_per_mw"] = t["rate_mbps"] / t["tx_mw"]                # throughput per mW transmitted
    t["mbps_x_km"] = t["rate_mbps"] * t["range_m"] / 1000         # range x throughput "reach" product

print("=" * 98)
print("DATASET AND DERIVED METRICS")
print("=" * 98)
print(f"{'Technology':<20}{'Class':<6}{'Range (m)':>10}{'Rate (Mbps)':>13}{'Tx (dBm)':>10}"
      f"{'Tx (mW)':>9}{'Mbps/m':>9}{'Mbps/mW':>10}{'Mbps*km':>10}")
for t in DATA:
    print(f"{t['name']:<20}{t['category']:<6}{t['range_m']:>10,}{t['rate_mbps']:>13,.1f}{t['tx_dbm']:>10}"
          f"{t['tx_mw']:>9.1f}{t['mbps_per_m']:>9.3f}{t['mbps_per_mw']:>10.2f}{t['mbps_x_km']:>10.1f}")

# =====================================================================
# 3. DEPLOYMENT SCENARIOS (explicit numbered requirements)
# =====================================================================
SCENARIOS = [
    {
        "id": "S1", "name": "Smart home with battery sensors",
        "range_m": 20, "rate_mbps": 0.3, "max_tx_dbm": 10,
        "requirements": [
            "30 sensors, each sending about 10 kbps, giving 0.3 Mbps aggregate",
            "Hub-to-sensor distance up to 20 m through interior walls",
            "Coin-cell battery for 2 years, so transmit power at most 10 dBm",
        ],
    },
    {
        "id": "S2", "name": "University campus network",
        "range_m": 100, "rate_mbps": 200, "max_tx_dbm": 60,
        "requirements": [
            "2,000 users across 5 buildings and the outdoor areas between them",
            "About 200 Mbps of demand per access-point cell",
            "Cell radius of 100 m in outdoor areas; mains/PoE power available",
        ],
    },
    {
        "id": "S3", "name": "Metro fixed-wireless link",
        "range_m": 4000, "rate_mbps": 40, "max_tx_dbm": 60,
        "requirements": [
            "Link 3 remote sites to a base station up to 4 km away",
            "40 Mbps aggregate demand per sector",
            "Outdoor deployment; mains power and tower access available",
        ],
    },
]

print("\n" + "=" * 98)
print("SCENARIO CHECK (PASS = meets range, throughput and power limit)")
print("=" * 98)
for s in SCENARIOS:
    print(f"\n{s['id']}: {s['name']}  [need >= {s['range_m']} m, >= {s['rate_mbps']} Mbps, "
          f"<= {s['max_tx_dbm']} dBm]")
    for t in DATA:
        ok_r = t["range_m"] >= s["range_m"]
        ok_t = t["rate_mbps"] >= s["rate_mbps"]
        ok_p = t["tx_dbm"] <= s["max_tx_dbm"]
        verdict = "PASS" if (ok_r and ok_t and ok_p) else "FAIL"
        why = []
        if not ok_r: why.append(f"range {t['range_m']} m too short")
        if not ok_t: why.append(f"rate {t['rate_mbps']} Mbps too low")
        if not ok_p: why.append(f"{t['tx_dbm']} dBm too high")
        print(f"   {t['name']:<20}{verdict}  {'; '.join(why)}")

# =====================================================================
# 4. TRADE-OFF CHART
# =====================================================================
COLORS = {"WPAN": "tab:green", "WLAN": "tab:blue", "WMAN": "tab:red"}

fig, ax = plt.subplots(figsize=(10, 6.5))
for t in DATA:
    size = 80 + 40 * math.sqrt(t["tx_mw"])           # marker area grows with transmit power
    ax.scatter(t["range_m"], t["rate_mbps"], s=size, color=COLORS[t["category"]],
               alpha=0.75, edgecolor="black", linewidth=0.8, zorder=3)

# label offsets chosen by hand so labels do not overlap: (dx, dy, horizontal alignment)
OFFSETS = {"Bluetooth 5 (BLE)": (12, 10, "left"), "Wi-Fi 5 (802.11ac)": (-14, -22, "right"),
           "Wi-Fi 6 (802.11ax)": (-14, 8, "right"), "WiMAX 802.16e": (16, -30, "left"),
           "WiMAX 802.16m": (14, 12, "left")}
for t in DATA:
    dx, dy, ha = OFFSETS[t["name"]]
    ax.annotate(f"{t['name']}\n({t['tx_dbm']} dBm)", (t["range_m"], t["rate_mbps"]),
                textcoords="offset points", xytext=(dx, dy), ha=ha, fontsize=8.5)

# scenario requirement points (a technology must sit to the upper-right of a star)
for s in SCENARIOS:
    ax.scatter(s["range_m"], s["rate_mbps"], marker="*", s=260, color="gold",
               edgecolor="black", zorder=4)
    dx, ha = (-12, "right") if s["id"] == "S3" else (12, "left")
    ax.annotate(s["id"], (s["range_m"], s["rate_mbps"]), textcoords="offset points",
                xytext=(dx, -4), ha=ha, fontsize=10, fontweight="bold")

ax.set_xscale("log")
ax.set_yscale("log")
ax.set_xlim(5, 40000)
ax.set_ylim(0.1, 6000)
ax.set_xlabel("Typical range (metres, log scale)")
ax.set_ylabel("Peak data rate (Mbps, log scale)")
ax.set_title("Range vs throughput vs transmit power: WPAN, WLAN and WMAN\n"
             "(marker size = device transmit power; stars = scenario requirements)")
ax.grid(True, which="both", alpha=0.3)

from matplotlib.lines import Line2D
handles = [Line2D([0], [0], marker="o", color="w", markerfacecolor=c, markeredgecolor="black",
                  markersize=10, label=k) for k, c in COLORS.items()]
handles.append(Line2D([0], [0], marker="*", color="w", markerfacecolor="gold",
                      markeredgecolor="black", markersize=14, label="Scenario requirement"))
ax.legend(handles=handles, loc="lower right")
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "wireless_tradeoff.png"), dpi=150)

# =====================================================================
# SOURCES
# =====================================================================
SOURCES = {
    1: "Electronic Design, '5 Things You Must Know About the New Bluetooth 5' (Bluetooth SIG briefing): "
       "https://www.electronicdesign.com/technologies/communications/wireless/article/21802861/5-things-you-must-know-about-the-new-bluetooth-5",
    2: "Android Authority, 'Bluetooth 5 explained': https://www.androidauthority.com/bluetooth-5-explained-762369/",
    3: "Intel, 'Different Wi-Fi Protocols and Data Rates': https://www.intel.com/content/www/us/en/support/articles/000005725/wireless.html",
    4: "Intel Wi-Fi 6E AX210 technical specifications (power limits): "
       "https://onlinehelp.ncrvoyix.com/Retail/SafetyCompliance/B005-0000-1589/Topics/RFIStatements/AX210/AX210TechSpec.htm",
    5: "L-com, '802.11 Wireless Standards' technical brief (typical ranges): "
       "https://l-com.com/images/downloadables/Technical-Briefs-And-Articles/802-11-Wireless-Standards.pdf",
    6: "Grandstream GWN7600LR datasheet (802.11ac outdoor AP, up to 300 m): "
       "https://www.grandstream.com/hubfs/Product_Documentation/datasheet_gwn7600_LR_english.pdf",
    7: "McGill University lecture note, 'WiMAX' (802.16e rates and cell radius): "
       "https://www.info413.ece.mcgill.ca/lecture%20note/E4%20WiMAX.pdf",
    8: "InfoWorld, 'First mobile WiMAX chip sets ready to ship': https://www.infoworld.com/article/2222093/first-mobile-wimax-chip-sets-ready-to-ship.html",
    9: "EDN, 'How much transmit power do WiMAX nets need?': https://www.edn.com/?p=4005852",
    10: "EE Times India (SiGe Semiconductor), 'Meet WiMAX power amp challenges', Dec 2008: "
        "https://nxtbook.com/nxtbooks/emedia/eetindia_20081201/index.php?startid=6",
    11: "RF Wireless World, 'IEEE 802.16 WiMAX Standards' (secondary source): "
        "https://www.rfwireless-world.com/articles/understanding-ieee-802-16-wimax-standards",
    12: "Powertec technical library, '802.11ax (Wi-Fi 6)': "
        "https://portal.powertec.com.au/technical-library/wireless/wireless-technologies/wifi/80211ax-wifi-6",
    13: "EE Asia, 'Bluetooth 5: More speeds, more range, new RF tests' (Bluetooth 5 mesh support): "
        "https://www.eetasia.com/bluetooth-5-more-speeds-more-range-new-rf-tests/",
}

print("\n" + "=" * 98)
print("SOURCES")
print("=" * 98)
for k, v in SOURCES.items():
    print(f"[{k}] {v}")

plt.show()