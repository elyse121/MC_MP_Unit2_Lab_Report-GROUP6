
import os
import numpy as np
import matplotlib.pyplot as plt
from scipy.special import erfc

np.random.seed(0)  # reproducible results
OUT_DIR = os.path.dirname(os.path.abspath(__file__))


# =====================================================================
# PART (a): FRIIS FREE-SPACE PATH LOSS
# =====================================================================
def friis_rx_power(Ptx_dBm, Gtx_dBi, Grx_dBi, d_km, f_MHz):
    """Received power in dBm (d in km, f in MHz)."""
    return (Ptx_dBm + Gtx_dBi + Grx_dBi
            - 20 * np.log10(d_km) - 20 * np.log10(f_MHz) - 32.44)


PTX, GTX, GRX = 43, 15, 0                 # dBm, dBi, dBi
distances = np.linspace(0.05, 10, 500)    # km
frequencies = [900, 1900, 3500]           # MHz

plt.figure(figsize=(8, 5))
for f in frequencies:
    plt.plot(distances, friis_rx_power(PTX, GTX, GRX, distances, f),
             label=f"{f} MHz")
plt.xscale("log")
plt.xlabel("Distance (km, log scale)")
plt.ylabel("Received power (dBm)")
plt.title("Friis free-space received power vs distance\n"
          f"(P_TX = {PTX} dBm, G_TX = {GTX} dBi, G_RX = {GRX} dBi)")
plt.grid(True, which="both", alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "friis_path_loss.png"), dpi=150)

# ---- 6 dB-per-doubling verification (printed output) ----
print("=" * 60)
print("PART (a): 6 dB-per-doubling check")
print("=" * 60)
for f in frequencies:
    p1 = friis_rx_power(PTX, GTX, GRX, 1.0, f)
    p2 = friis_rx_power(PTX, GTX, GRX, 2.0, f)
    print(f"Doubling distance 1 km -> 2 km at {f:>4} MHz: "
          f"{p1:7.2f} dBm -> {p2:7.2f} dBm  (drop = {p1 - p2:.2f} dB)")

d_fixed = 1.0
for f in frequencies:
    p1 = friis_rx_power(PTX, GTX, GRX, d_fixed, f)
    p2 = friis_rx_power(PTX, GTX, GRX, d_fixed, 2 * f)
    print(f"Doubling frequency {f:>4} -> {2 * f:>4} MHz at 1 km: "
          f"{p1:7.2f} dBm -> {p2:7.2f} dBm  (drop = {p1 - p2:.2f} dB)")
print("Theoretical value: 20*log10(2) = 6.02 dB\n")


# =====================================================================
# PART (b): BPSK AND 16-QAM BER OVER AWGN
# =====================================================================
N_BITS = 10**6                            # divisible by 4 (needed for 16-QAM)

# ---- Mappers ----
def bpsk_map(bits):
    return 2.0 * bits - 1.0               # 0 -> -1, 1 -> +1

# Gray code for one 16-QAM axis: 2 bits -> level
GRAY_LEVELS = {(0, 0): -3, (0, 1): -1, (1, 1): +1, (1, 0): +3}
LEVEL_TO_BITS = {v: k for k, v in GRAY_LEVELS.items()}
QAM_NORM = np.sqrt(10)                    # unit average symbol energy

def qam16_map(bits):
    b = bits.reshape(-1, 4)
    i_lvl = np.array([GRAY_LEVELS[(x, y)] for x, y in b[:, 0:2]])
    q_lvl = np.array([GRAY_LEVELS[(x, y)] for x, y in b[:, 2:4]])
    return (i_lvl + 1j * q_lvl) / QAM_NORM

# ---- Demappers (minimum-distance decision) ----
def bpsk_demap(rx):
    return (rx.real > 0).astype(int)

def qam16_demap(rx):
    levels = np.array([-3, -1, 1, 3]) / QAM_NORM

    def nearest(x):
        return levels[np.argmin(np.abs(x[:, None] - levels[None, :]), axis=1)]

    i_hat = np.round(nearest(rx.real) * QAM_NORM).astype(int)
    q_hat = np.round(nearest(rx.imag) * QAM_NORM).astype(int)
    out = np.zeros((len(rx), 4), dtype=int)
    for k in range(len(rx)):
        out[k, 0:2] = LEVEL_TO_BITS[i_hat[k]]
        out[k, 2:4] = LEVEL_TO_BITS[q_hat[k]]
    return out.reshape(-1)

# ---- AWGN channel ----
def awgn(symbols, ebn0_db, bits_per_symbol):
    """Add complex Gaussian noise for a target Eb/N0 (Es = 1)."""
    ebn0 = 10 ** (ebn0_db / 10)
    n0 = 1.0 / (bits_per_symbol * ebn0)          # Es = k*Eb = 1  ->  N0 = 1/(k*EbN0)
    sigma = np.sqrt(n0 / 2)                      # per real dimension
    noise = sigma * (np.random.randn(len(symbols))
                     + 1j * np.random.randn(len(symbols)))
    return symbols + noise


# ---- Monte Carlo sweep ----
ebn0_range = np.arange(0, 16.5, 0.5)             # dB
bits = np.random.randint(0, 2, size=N_BITS)

ber_bpsk, ber_qam = [], []
for ebn0_db in ebn0_range:
    rx = awgn(bpsk_map(bits).astype(complex), ebn0_db, 1)
    ber_bpsk.append(np.mean(bpsk_demap(rx) != bits))

    rx = awgn(qam16_map(bits), ebn0_db, 4)
    ber_qam.append(np.mean(qam16_demap(rx) != bits))

ber_bpsk, ber_qam = np.array(ber_bpsk), np.array(ber_qam)

# ---- Theoretical curves ----
ebn0_lin = 10 ** (ebn0_range / 10)
theory_bpsk = 0.5 * erfc(np.sqrt(ebn0_lin))
theory_qam16 = (3 / 8) * erfc(np.sqrt(0.4 * ebn0_lin))   # standard Gray-coded approximation

# ---- Plot ----
plt.figure(figsize=(8, 5.5))
mask_b, mask_q = ber_bpsk > 0, ber_qam > 0       # zero errors cannot be shown on a log axis
plt.semilogy(ebn0_range[mask_b], ber_bpsk[mask_b], "o", label="BPSK (simulated)")
plt.semilogy(ebn0_range[mask_q], ber_qam[mask_q], "s", label="16-QAM (simulated)")
plt.semilogy(ebn0_range, theory_bpsk, "--", color="C0", label="BPSK (theory)")
plt.semilogy(ebn0_range, theory_qam16, "--", color="C1", alpha=0.6, label="16-QAM (theory, approx.)")
plt.axhline(1e-3, color="gray", linestyle=":", label="Target BER = $10^{-3}$")
plt.ylim(1e-6, 1)
plt.xlabel("$E_b/N_0$ (dB)")
plt.ylabel("Bit error rate")
plt.title(f"BER vs $E_b/N_0$ over AWGN ({N_BITS:,} bits per point)")
plt.grid(True, which="both", alpha=0.3)
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUT_DIR, "ber_bpsk_16qam.png"), dpi=150)

# ---- Numeric gap at target BER (interpolated in the log-BER domain) ----
def ebn0_at_ber(ebn0_db, ber, target):
    ok = ber > 0
    x, y = ebn0_db[ok], np.log10(ber[ok])
    # BER decreases with Eb/N0, so reverse arrays for np.interp (needs increasing x)
    return float(np.interp(np.log10(target), y[::-1], x[::-1]))

TARGET_BER = 1e-3
need_bpsk = ebn0_at_ber(ebn0_range, ber_bpsk, TARGET_BER)
need_qam = ebn0_at_ber(ebn0_range, ber_qam, TARGET_BER)
gap_ebn0 = need_qam - need_bpsk
gap_snr = gap_ebn0 + 10 * np.log10(4 / 1)        # Es/N0 = Eb/N0 + 10*log10(bits per symbol)

print("=" * 60)
print("PART (b): BER results")
print("=" * 60)
print(f"Bits per simulated point          : {N_BITS:,}")
print(f"Target BER                        : {TARGET_BER:.0e}")
print(f"Eb/N0 needed by BPSK              : {need_bpsk:.2f} dB")
print(f"Eb/N0 needed by 16-QAM            : {need_qam:.2f} dB")
print(f"Gap in Eb/N0 (16-QAM - BPSK)      : {gap_ebn0:.2f} dB")
print(f"Gap in symbol SNR (Es/N0)         : {gap_snr:.2f} dB")
print("  (Es/N0 = Eb/N0 + 10*log10(bits/symbol); 16-QAM carries 4 bits/symbol, BPSK 1)")

# ---- Sanity check: simulation vs theory for BPSK ----
idx = np.argmin(np.abs(ebn0_range - 6))
print(f"\nSanity check at Eb/N0 = 6 dB: BPSK simulated = {ber_bpsk[idx]:.2e}, "
      f"theory = {theory_bpsk[idx]:.2e}")

plt.show()