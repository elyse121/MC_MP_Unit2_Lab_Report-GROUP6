"""
Mobile Communications - Unit 2 - Mini Project 2.2
OFDM Waveform Generator with a Cyclic Prefix Visualizer

Chain: bits -> Gray-coded 16-QAM -> N subcarriers -> IFFT -> add cyclic prefix
       -> multipath FIR channel (+ small AWGN) -> remove CP -> FFT
       -> one-tap equalizer -> hard decision -> error metrics.

Several consecutive OFDM symbols are sent back to back, so the tail of one
symbol can smear into the next (ISI) when the cyclic prefix is too short.

Requires: numpy, matplotlib
Run:      python mini_project_2_2.py
"""

import os
from typing import Optional
import numpy as np
import matplotlib.pyplot as plt

OUT_DIR = os.path.dirname(os.path.abspath(__file__))
rng = np.random.default_rng(0)          # reproducible results

N = 64                                  # subcarriers per OFDM symbol
SNR_DB = 35                             # receiver noise used in the experiments

# ---------------------------------------------------------------------
# Synthetic multipath channel: 4 taps at delays 0, 2, 5 and 9 samples
# (complex gains), so the delay spread is 9 samples -> CP >= 9 is needed.
# ---------------------------------------------------------------------
TAP_DELAYS = [0, 2, 5, 9]
TAP_GAINS = np.array([1.0, 0.7 * np.exp(1j * 0.8), 0.5 * np.exp(-1j * 1.9), 0.4 * np.exp(1j * 2.5)])
h = np.zeros(max(TAP_DELAYS) + 1, dtype=complex)
for d, g in zip(TAP_DELAYS, TAP_GAINS):
    h[d] = g
h /= np.linalg.norm(h)                  # unit channel energy
DELAY_SPREAD = max(TAP_DELAYS)          # samples
H_FREQ = np.fft.fft(h, N)               # channel frequency response on the N subcarriers


# =====================================================================
# 1. Gray-coded 16-QAM mapper / demapper
#    Each axis carries 2 bits: 00 -> -3, 01 -> -1, 11 -> +1, 10 -> +3
#    (neighbouring levels differ in exactly one bit), normalized to unit energy.
# =====================================================================
QAM_NORM = np.sqrt(10)
GRAY_LEVELS = np.array([-3, -1, 3, 1])           # index = 2*b0 + b1

def qam16_map(bits):
    b = bits.reshape(-1, 4)
    i_lvl = GRAY_LEVELS[2 * b[:, 0] + b[:, 1]]
    q_lvl = GRAY_LEVELS[2 * b[:, 2] + b[:, 3]]
    return (i_lvl + 1j * q_lvl) / QAM_NORM

def qam16_bits(symbols):
    """Hard decision (minimum distance). Returns bits with shape (4, *symbols.shape)."""
    i, q = symbols.real * QAM_NORM, symbols.imag * QAM_NORM
    return np.stack([i > 0, np.abs(i) < 2, q > 0, np.abs(q) < 2])

def qam16_demap(symbols):
    return qam16_bits(symbols).T.reshape(-1).astype(int) if symbols.ndim == 1 else None


# =====================================================================
# 2. OFDM transmitter / receiver building blocks
# =====================================================================
def ofdm_modulate(X):
    """X: (n_symbols, N) frequency-domain symbols -> time-domain waveform."""
    return np.fft.ifft(X, axis=1, norm="ortho")

def add_cp(x, cp):
    """Prepend a cyclic prefix = copy of the last `cp` samples of each symbol."""
    if cp == 0:
        return x
    return np.hstack([x[:, -cp:], x])

def ofdm_demodulate(rx_blocks, cp):
    """Discard the CP of each block, then FFT the remaining N samples."""
    return np.fft.fft(rx_blocks[:, cp:cp + N], axis=1, norm="ortho")

def channel(tx_stream, snr_db: Optional[float] = None):
    """Convolve with the multipath FIR filter and optionally add AWGN."""
    rx = np.convolve(tx_stream, h)[:len(tx_stream)]
    if snr_db is not None:
        sigma = np.sqrt(10 ** (-snr_db / 10) / 2)
        rx = rx + sigma * (rng.standard_normal(len(rx)) + 1j * rng.standard_normal(len(rx)))
    return rx

def run_link(n_symbols, cp, snr_db: Optional[float] = SNR_DB):
    """Send n_symbols back-to-back OFDM symbols; return (sent X, equalized Y)."""
    bits = rng.integers(0, 2, size=n_symbols * N * 4)
    X = qam16_map(bits).reshape(n_symbols, N)
    tx = add_cp(ofdm_modulate(X), cp).reshape(-1)           # serial stream
    rx = channel(tx, snr_db).reshape(n_symbols, N + cp)     # back to per-symbol blocks
    Y = ofdm_demodulate(rx, cp) / H_FREQ                    # FFT + one-tap equalizer
    return X, Y

def metrics(X, Y):
    """SER and MSE, ignoring symbol 0 (it has no previous symbol to smear into it)."""
    X, Y = X[1:], Y[1:]
    sent_bits, got_bits = qam16_bits(X), qam16_bits(Y)       # shape (4, symbols, N)
    ser = np.mean(np.any(sent_bits != got_bits, axis=0))    # symbol error = any of its 4 bits wrong
    mse = np.mean(np.abs(Y - X) ** 2)
    return ser, mse


# =====================================================================
# 3. SELF-CHECKS (unit tests)
# =====================================================================
print("=" * 62)
print("SELF-CHECKS")
print("=" * 62)

# (a) mapper: unit energy, and map -> demap round trip
test_bits = rng.integers(0, 2, size=4000)
syms = qam16_map(test_bits)
assert np.allclose(np.mean(np.abs(syms) ** 2), 1.0, atol=0.05)
assert np.array_equal(qam16_bits(syms).T.reshape(-1).astype(int), test_bits)
print("[PASS] 16-QAM mapper: unit average energy and exact round trip")

# (b) noiseless IFFT -> FFT recovers the subcarrier values exactly
X_test = qam16_map(rng.integers(0, 2, size=N * 4)).reshape(1, N)
assert np.allclose(np.fft.fft(ofdm_modulate(X_test), axis=1, norm="ortho"), X_test)
print("[PASS] FFT of noiseless IFFT output recovers the original subcarrier values")

# (c) cyclic prefix equals the tail of the OFDM symbol
x_test = ofdm_modulate(X_test)
with_cp = add_cp(x_test, 16)
assert np.allclose(with_cp[0, :16], x_test[0, -16:])
print("[PASS] CP samples match the tail of the OFDM symbol (CP = 16)")

# (d) noiseless link through the multipath channel: CP >= delay spread -> exact recovery
X_ok, Y_ok = run_link(50, cp=16, snr_db=None)
assert np.allclose(X_ok, Y_ok, atol=1e-9)
print(f"[PASS] Noiseless multipath link with CP = 16 (>= {DELAY_SPREAD}) recovers all symbols exactly")

X_bad, Y_bad = run_link(50, cp=0, snr_db=None)
print(f"[INFO] Same noiseless channel with CP = 0: max error magnitude = {np.max(np.abs(X_bad[1:] - Y_bad[1:])):.3f} (ISI/ICI damage)")


# =====================================================================
# 4. FIGURE 1 - constellations with sufficient vs insufficient CP
# =====================================================================
N_SYMS_PLOT = 150
cases = [(16, f"Sufficient CP = 16\n(>= delay spread {DELAY_SPREAD})"),
         (4, f"Too-short CP = 4\n(< delay spread {DELAY_SPREAD})"),
         (0, "No CP = 0")]

fig, axes = plt.subplots(1, 3, figsize=(14, 5.6))
lv = np.array([-3, -1, 1, 3]) / QAM_NORM
ideal = (lv[:, None] + 1j * lv[None, :]).reshape(-1)
for ax, (cp, title) in zip(axes, cases):
    X, Y = run_link(N_SYMS_PLOT, cp)
    ser, mse = metrics(X, Y)
    pts = Y[1:].reshape(-1)
    ax.scatter(pts.real, pts.imag, s=3, alpha=0.3)
    ax.scatter(ideal.real, ideal.imag, c="red", marker="x", s=80, label="ideal 16-QAM points")
    ax.set_title(f"{title}\nSER = {ser:.3f}, MSE = {mse:.4f}")
    ax.set_xlim(-1.8, 1.8)
    ax.set_ylim(-1.8, 1.8)
    ax.set_aspect("equal")
    ax.set_xlabel("In-phase")
    ax.grid(alpha=0.3)
axes[0].set_ylabel("Quadrature")
axes[0].legend(loc="upper right", fontsize=8)
fig.suptitle(f"Recovered constellations after multipath (SNR = {SNR_DB} dB, equalized)")
fig.tight_layout(rect=(0, 0, 1, 0.96))
fig.savefig(os.path.join(OUT_DIR, "ofdm_constellations.png"), dpi=150)


# =====================================================================
# 5. FIGURE 2 - error rate vs CP length
# =====================================================================
cp_values = np.arange(0, 21)
N_SYMS_SWEEP = 3000
sers, mses = [], []
for cp in cp_values:
    X, Y = run_link(N_SYMS_SWEEP, cp)
    s, m = metrics(X, Y)
    sers.append(s)
    mses.append(m)
sers, mses = np.array(sers), np.array(mses)

fig, (a1, a2) = plt.subplots(1, 2, figsize=(12, 4.5))
a1.plot(cp_values, sers, "o-")
a1.axvline(DELAY_SPREAD, color="red", linestyle="--", label=f"delay spread = {DELAY_SPREAD} samples")
a1.set_xlabel("Cyclic prefix length (samples)")
a1.set_ylabel("Symbol error rate")
a1.set_title("Symbol error rate vs CP length")
a1.grid(alpha=0.3)
a1.legend()

a2.semilogy(cp_values, mses, "s-", color="C1")
a2.axvline(DELAY_SPREAD, color="red", linestyle="--", label=f"delay spread = {DELAY_SPREAD} samples")
a2.set_xlabel("Cyclic prefix length (samples)")
a2.set_ylabel("Mean-squared error (log scale)")
a2.set_title("MSE of recovered constellation vs CP length")
a2.grid(alpha=0.3, which="both")
a2.legend()
fig.tight_layout()
fig.savefig(os.path.join(OUT_DIR, "ofdm_error_vs_cp.png"), dpi=150)

print()
print("=" * 62)
print(f"ERROR RATE vs CP LENGTH  (N = {N}, delay spread = {DELAY_SPREAD}, SNR = {SNR_DB} dB)")
print("=" * 62)
print(f"{'CP':>4} {'SER':>10} {'MSE':>12} {'Overhead':>10}")
for cp, s, m in zip(cp_values, sers, mses):
    overhead = 100 * cp / (N + cp)
    marker = "  <-- CP = delay spread" if cp == DELAY_SPREAD else ""
    print(f"{cp:>4} {s:>10.4f} {m:>12.5f} {overhead:>9.1f}%{marker}")

plt.show()